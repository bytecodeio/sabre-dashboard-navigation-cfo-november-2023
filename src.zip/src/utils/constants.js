export const drawerWidth = "325px";
export const toolbarHeight = "63px";
export const defaultLogoHeight = 40;



export const LOOKER_MODEL = "thelook_partner";
export const LOOKER_EXPLORE = "events";

export const DASHBOARD_ID =

  "thelook_partner::web_analytics_overview";


  export const TAGKEYS = {
    dimensions: 'dimensions',
    measures: 'measures',
    timeframe: 'timeframes',
    filterOnly: 'filterOnly'
}
