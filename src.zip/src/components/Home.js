import React, { createContext, useEffect, useState, useContext } from "react";
import "normalize.css";
import { ExtensionContext } from "@looker/extension-sdk-react";
import { TopAppBar } from "./TopAppBar/TopAppBar";
import { AppLoadingSpinner } from "./_lowLevel/AppLoadingSpinner";
import { LeftDrawer } from "./LeftDrawer/LeftDrawer";
import { EmbedDashboard } from "./EmbedDashboard/EmbedDashboard";
import { Alert, Box, Snackbar } from "@mui/material";
import { ErrorBoundary } from "./_lowLevel/ErrorBoundary";
import { drawerWidth, toolbarHeight } from "../utils/constants";
import { useIsUserAdmin } from "../hooks/useIsUserAdmin";
import { useInitTabs } from "../hooks/useInitTabs";
import { sortDashboards } from "../utils/utils";
import { useHistory } from "react-router-dom";
import { useExtensionContext } from "../hooks/useExtensionContext";



import {
  LOOKER_MODEL,
  LOOKER_EXPLORE,
  TAGKEYS,
  DASHBOARD_ID,
} from "./../utils/constants.js";

export const AppAlertContext = createContext();

export const Home = () => {
  const history = useHistory();
  const { core40SDK: sdk, extensionSDK } = useContext(ExtensionContext);

  const [isLeftDrawerOpen, setIsLeftDrawerOpen] = useState(true);
  const [selectedDashboardId, setSelectedDashboardId] = useState();
  const [selectedDashboardFilters, setSelectedDashboardFilters] = useState();


  // get application context data on load
const [reload, setReload] = useState({});
const reloadPage = () => {
  setSelectedDashboardId();
  setReload({});
};
const [isLoadingContextData, setIsLoadingContextData] = useState(true);
const [appConfig, setAppConfig] = useState();
const fallbackAppConfig = {
  showDashboardFilters: true,
  dashboardTheme: "Looker",
  showTabIcons: false,
  tabs: [
    {
      name: "",
      basicContentFolderId: null,
    },
  ],
};
const getContextData = async () => {
  setIsLoadingContextData(true);
  try {
    const contextData = await extensionSDK.getContextData();
    setAppConfig({
      ...fallbackAppConfig,
      ...contextData,
    });
  } catch (e) {
    setAppError(`Error loading app context data`);
    console.error("Error loading app context data: ", e);
  }
  setIsLoadingContextData(false);
};
useEffect(() => {
  getContextData();
}, [reload]);

  // check whether user is an admin user on load
const [isCheckingAdminUser, setIsCheckingAdminUser] = useState(true);
const [isAdminUser, setIsAdminUser] = useState(false);
const checkAdminUser = async () => {
  try {
    const { id: currentUserId } = await sdk.ok(sdk.me("id"));
    const response = await sdk.ok(
      sdk.user_roles({
        user_id: currentUserId,
        fields: "name",
      })
    );
    const isAdmin = response.some(
      ({ name: roleName }) => roleName === "Admin"
    );
    setIsAdminUser(isAdmin);
  } catch (e) {
    setAppError("Error checking user admin status");
    console.error("Error checking user admin status: ", e);
  }
  setIsCheckingAdminUser(false);
};
useEffect(() => {
  checkAdminUser();
}, []);


  // snackbar alert
  const defaultAppAlert = {
    message: "",
    type: "success",
  };
  const [appAlert, setAppAlert] = useState(defaultAppAlert);
  const handleSnackbarClose = () => {
    setAppAlert(defaultAppAlert);
  };
  const setAppError = (message) => setAppAlert({ message, type: "error" });




  // // fetch folder dashboards on load, after checking admin user status
  const { isInitializingTabs, tabData } = useInitTabs({
    appConfig,
    setAppAlert,
    setSelectedDashboardId,
    isCheckingAdminUser,
    isAdminUser,
  });

  const drawerListItems = tabData?.map((tab) => {
    const formatAndSortDashboards = function (dashboards, dashboardSortOrder) {
      if (!dashboards) {
        return undefined;
      }
      const sortedDashboards = dashboardSortOrder
        ? sortDashboards(dashboards, dashboardSortOrder)
        : [...dashboards];

      const formattedDashboards = sortedDashboards.map((d) => ({
        label: d.title,
        value: d.id,
      }));
      return formattedDashboards;
    };

    // format and sort tab dashboards
    const formattedDashboards = formatAndSortDashboards(
      tab.dashboards,
      tab.dashboardSortOrder
    );

    const formattedChildren = formattedDashboards
      ? [...formattedDashboards]
      : [];

    // format and prepend nested tabs
    if (tab.children?.length) {
      const formattedNestedTabs = tab.children.map((nestedTab) => {
        const formattedDashboards = formatAndSortDashboards(
          nestedTab.dashboards,
          nestedTab.dashboardSortOrder
        );
        return {
          label: nestedTab.name,
          children: formattedDashboards,
        };
      });

      formattedChildren.unshift(...formattedNestedTabs);
    }

    const listItems = {
      label: tab.name,
      children: formattedChildren,
    };

    return listItems;
  });

  // handle dashboard selection
  const handleDashboardSelection = (newDashboardId) => {
    setSelectedDashboardId(newDashboardId);
    history.push(`/${newDashboardId}`);
  };

  console.log(selectedDashboardId)

  console.log("elizabeth")


console.log(selectedDashboardId, "zero")
useEffect( () => {

 sdk.ok(sdk.dashboard(1288)).then((res) => {
    console.log(res);

    for (let result in res.dashboard_filters) {
      let query = res.dashboard_filters[result].field;

      console.log('this is getting the Filter Values of dashboard 1288', query);

    }
  });
}, []);

useEffect( () => {
sdk.ok(sdk.model_fieldname_suggestions(
  {
    model_name: 'system__activity',
    view_name: 'event_attribute',
    field_name: 'event.name'
  }))
}, []);

useEffect( async () => {
    let response = await sdk.ok(sdk.dashboard(1020)).then((res) => {
        Promise.all(
          res.dashboard_filters.map(
            (element) =>
              new Promise((resolve, reject) => {
                sdk
                  .ok(sdk.model_fieldname_suggestions())
                  .then((res) => {
                    console.log(res, "dfvkjbdksbvub");

                  })
                  .catch((err) => {
                    console.log("err", err);
                    reject();
                  });
              })
          )
        ).then((values) => {
          setDashboardData(values);
        });
      });
    }, []);


//
// useEffect(() => {
// console.log(selectedDashboardId, "one")
// const getDashboardFields = async (selectedDashboardId) => {
//   let fields = await sdk.ok(
//     sdk.dashboard(selectedDashboardId, 'fields')
//   )
//
//     console.log(fields, "two")
//
//   const dimensions = fields['fields']['dimensions']
//   const measures = fields['fields']['measures']
//
//   let dims = filterOutValues(dimensions)
//   let meas = filterOutValues(measures)
//   let filters = dims.concat(meas)
//
// console.log(dims, "dims")
//
//   return {
//     filters,
//     measures: meas,
//     dimensions: dims,
//   }
// }
//
// }, []);

  //
  // selectedExplore.filters
  // // Get dimension fields from explore by tag name
  // const dimensionFieldsByCategory = groupByKey(
  //   selectedExplore.filters,
  //   tagKeys.dimensions
  // )
  // const timeframeFieldsByCategory = groupByKey(
  //   selectedExplore.filters,
  //   tagKeys.timeframe
  // )
  // const dimensionFields = {}
  // Object.values(dimensionFieldsByCategory).forEach((dimensionFieldList) => {
  //   dimensionFieldList.forEach((dimensionField) => {
  //     dimensionFields[dimensionField.name] = dimensionField
  //   })
  // })
  // Object.values(timeframeFieldsByCategory).forEach((timeframeFieldList) => {
  //   timeframeFieldList.forEach((timeframeField) => {
  //     dimensionFields[timeframeField.name] = timeframeField
  //   })
  // })
  //
  // const filterFields = { ...dimensionFields }
  // const filterOnlyFieldsByCategory = groupByKey(
  //   selectedExplore.filters,
  //   tagKeys.filterOnly
  // )
  // if (Object.values(filterOnlyFieldsByCategory).length > 0) {
  //   Object.values(filterOnlyFieldsByCategory).forEach((filterOnlyFieldList) => {
  //     filterOnlyFieldList.forEach((filterOnlyField) => {
  //       filterFields[filterOnlyField.name] = filterOnlyField
  //     })
  //   })
  // }
  //
  // // Dimension selector
  // const [dimensionSelection, setDimensionSelection] = useState([])
  //
  // const dimensionOptions = Object.values(dimensionFields).map(
  //   (dimensionField) => {
  //     const { name, label_short } = dimensionField
  //     return {
  //       name,
  //       label_short,
  //     }
  //   }
  // )
  //
  // // Get measure fields from explore by tag name
  // const measureFieldsByCategory = groupByKey(
  //   selectedExplore.filters,
  //   tagKeys.measures
  // )
  // const measureFields = {}
  // Object.values(measureFieldsByCategory).forEach((measureFieldList) => {
  //   measureFieldList.forEach((measureField) => {
  //     measureFields[measureField.name] = measureField
  //   })
  // })
  //
  // // Measure selector
  // const [measureSelection, setMeasureSelection] = useState([])
  //
  // const measureOptions = Object.values(measureFields).map((measureField) => {
  //   const { name, label_short } = measureField
  //   return {
  //     name,
  //     label_short,
  //   }
  // })
  //
  // // Filters sidebar
  // const filterOptions = Object.values(filterFields).map((filterField) => {
  //   const { name, label_short } = filterField
  //   return {
  //     name,
  //     label_short,
  //   }
  // })



  return (
    <AppAlertContext.Provider value={setAppAlert}>
      <Box height="100%" display="flex" flexDirection="column">
        <ErrorBoundary>
          {isInitializingTabs || isCheckingAdminUser ? (
            <AppLoadingSpinner message="Loading Folders" />
          ) : (
            <>
              {appConfig?.showAppBar !== false && (
                <TopAppBar
                  appConfig={appConfig}
                  onMenuClick={() => setIsLeftDrawerOpen((prev) => !prev)}
                  toolbarHeight={toolbarHeight}
                />
              )}
              <Box flexGrow={1} display="flex">
                <LeftDrawer
                  heightOffset={
                    appConfig?.showAppBar !== false ? toolbarHeight : 0
                  }
                  drawerWidth={drawerWidth}
                  isOpen={isLeftDrawerOpen}
                  drawerListItems={drawerListItems}
                  selectedItem={selectedDashboardId}
                  setSelectedItem={handleDashboardSelection}
                  appConfig={appConfig}
                  isAdminUser={isAdminUser}
                />
                <Box
                  sx={{
                    height: "100%",
                    width: isLeftDrawerOpen
                      ? `calc(100% - ${drawerWidth})`
                      : "100%",
                    marginLeft: isLeftDrawerOpen ? drawerWidth : 0,
                    transition: (theme) =>
                      theme.transitions.create(["margin", "width"], {
                        easing: theme.transitions.easing.easeOut,
                        duration: theme.transitions.duration.enteringScreen,
                      }),
                  }}
                >
                  {appConfig?.tabs?.length > 0 ? (
                    <EmbedDashboard
                      dashboardId={selectedDashboardId}
                      showDashboardFilters={appConfig?.showDashboardFilters}
                    />
                  ) : (
                    <Alert severity="warning">
                      Please define folders in the admin config pane.
                    </Alert>
                  )}
                </Box>
              </Box>
            </>
          )}
        </ErrorBoundary>
        <Snackbar
          anchorOrigin={{ vertical: "top", horizontal: "right" }}
          open={!!appAlert.message}
          autoHideDuration={8000}
          onClose={handleSnackbarClose}
        >
          <Alert severity={appAlert.type}>{appAlert.message}</Alert>
        </Snackbar>
      </Box>
    </AppAlertContext.Provider>
  );
};
