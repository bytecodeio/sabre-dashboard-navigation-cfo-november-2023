import React, { useContext, useEffect, useState, useCallback } from "react";
import {
  Box,
  Button,
  DialogActions,
  DialogContent,
  FormControl,
  FormControlLabel,
  Grid,
  InputLabel,
  IconButton,
  Select,
  Stack,
  Switch,
  TextField,
  Tooltip,
} from "@mui/material";
import { ExtensionContext } from "@looker/extension-sdk-react";
import { LoadingButton } from "@mui/lab";
import {
  CreateNewFolder,
  Delete,
  FileUpload,
  SubdirectoryArrowRight,
  SwapVert,
} from "@mui/icons-material";
import { DialogContentSection } from "./DialogContentSection";
import produce from "immer";
import defaultLogo from "../../../assets/BytecodeLogo.png";
import { defaultLogoHeight } from "../../../utils/constants";
import Dropzone from "react-dropzone";

const TabConfigRow = ({
  addNestedTab,
  tabIndex,
  tab,
  updateNestedTab,
  updateTab,
  removeNestedTab,
  removeTab,
  setSelectedTab,
  allGroups
}) => (
  <>

<Grid container spacing={2} pl={2} py={2} width="100%" className="d-flex justify-content-center">
      <Grid item xs={2}>

          <TextField
            value={tab.name}
            onChange={(e) => updateTab("name", e.target.value, tabIndex)}
            variant="outlined"
            label={`Tab ${tabIndex + 1} Name`}
            size="small"
            sx={{ width: "100%" }}
          />

      </Grid>
      <Grid item xs={1}>

          <TextField
            value={tab.folderId}
            onChange={(e) => updateTab("folderId", e.target.value, tabIndex)}
            variant="outlined"
            label={`Folder ID`}
            size="small"
            sx={{ width: "100%" }}
          />

      </Grid>

<Grid item xs={2}>
  <FormControl sx={{ width: "100%" }}>
    <InputLabel id="groups-visible-to-label">Groups Visible To</InputLabel>
    <Select
      labelId="groups-visible-to-label"
      multiple
      onChange={(e) => {
        const newValue =
          typeof e.target.value === "string"
            ? e.target.value.split(",")
            : e.target.value;
        updateTab("groupsVisibleTo", newValue, tabIndex);
      }}
      size="small"
      value={tab.groupsVisibleTo ?? []}
    >
      {allGroups.map((group) => (
        <MenuItem key={group.id} value={group.id}>
          {group.name}
        </MenuItem>
      ))}
    </Select>
  </FormControl>
</Grid>

<Grid item xs={2}>
  <FormControl sx={{ width: "100%" }}>

    <TextField
      value=""
      onChange={(e) => updateTab("folderId", e.target.value, tabIndex)}
      variant="outlined"
      label="Add Link Name"
      size="small"
      sx={{ width: "100%" }}
    />
  </FormControl>
</Grid>

<Grid item xs={2}>
  <FormControl sx={{ width: "100%" }}>

    <TextField
      value=""
      onChange={(e) => updateTab("folderId", e.target.value, tabIndex)}
      variant="outlined"
      label="Add Studio Link"
      size="small"
      sx={{ width: "100%" }}
    />
  </FormControl>
</Grid>


<Grid item xs="auto">
  <Tooltip title="Add Nested Tab">
    <IconButton
      onClick={() => addNestedTab(tabIndex)}
      sx={{
        visibility: tab.children?.length ? "hidden" : "visible",
      }}
    >
      <CreateNewFolder />
    </IconButton>
  </Tooltip>
</Grid>
<Grid item xs="auto">
  <Tooltip title="Sort Tab Dashboards">
    <IconButton
      onClick={() =>
        setSelectedTab({ tabIndex, nestedTabIndex: undefined })
      }
    >
      <SwapVert />
    </IconButton>
  </Tooltip>
</Grid>
<Grid item xs="auto">
  <Tooltip title="Remove Tab">
    <IconButton onClick={() => removeTab(tabIndex)}>
      <Delete color="error" />
    </IconButton>
  </Tooltip>
</Grid>
</Grid>
{tab.children?.map((nestedTab, nestedTabIndex) => (
<Grid container spacing={2} pl={2} py={2}  width="100%" key={nestedTabIndex}  className="d-flex justify-content-center">
  <Grid item xs="auto">
    <SubdirectoryArrowRight
      sx={{ color: "rgba(0, 0, 0, 0.54)", pr: 1 }}
    />
  </Grid>
  <Grid item xs>
    <Box pr={2}>
      <TextField
        value={nestedTab.name}
        onChange={(e) =>
          updateNestedTab(
            "name",
            e.target.value,
            tabIndex,
            nestedTabIndex
          )
        }
        variant="outlined"
        label={`Tab ${tabIndex + 1}-${nestedTabIndex + 1} Name`}
        size="small"
        sx={{ width: "100%", pr: 2 }}
      />
    </Box>
  </Grid>
  <Grid item xs={3}>
    <Box pr={1}>
      <TextField
        value={nestedTab.folderId}
        onChange={(e) =>
          updateNestedTab(
            "folderId",
            e.target.value,
            tabIndex,
            nestedTabIndex
          )
        }
        variant="outlined"
        label={`Folder ID`}
        size="small"
        sx={{ width: "100%" }}
      />
    </Box>
  </Grid>
  <Grid item xs="auto">
    <Tooltip
      title="Add Nested Tab"
      sx={{
        visibility:
          nestedTabIndex === tab.children.length - 1
            ? "visible"
            : "hidden",
      }}
    >
      <IconButton onClick={() => addNestedTab(tabIndex)}>
        <CreateNewFolder />
      </IconButton>
    </Tooltip>
  </Grid>
  <Grid item xs="auto">
    <Tooltip title="Sort Tab Dashboards">
      <IconButton
        onClick={() => setSelectedTab({ tabIndex, nestedTabIndex })}
      >
        <SwapVert />
      </IconButton>
    </Tooltip>
  </Grid>
  <Grid item xs="auto">
    <Tooltip title="Remove Tab">
      <IconButton
        onClick={() => removeNestedTab(tabIndex, nestedTabIndex)}
      >
        <Delete color="error" />
      </IconButton>
    </Tooltip>
  </Grid>
</Grid>
))}



  </>
);

export const AppConfig = ({
  tempAppConfig,
  setTempAppConfig,
  saveConfigChanges,
  isSavingConfig,
  closeModal,
  setSelectedTab,
}) => {

  const { core40SDK: sdk } = useContext(ExtensionContext);

  // Get all Looker groups on load
  const [allGroups, setAllGroups] = useState([]);
  const [isLoadingGroups, setIsLoadingGroups] = useState(true);
  const fetchLookerGroups = async () => {
    try {
      const groups = await sdk.ok(
        sdk.all_groups({
          fields: "id, name",
        })
      );
      setAllGroups(groups);
      setIsLoadingGroups(false);
    } catch (e) {
      setAppAlert({
        message: "Error loading Looker groups",
        type: "error",
      });
      setIsLoadingGroups(false);
    }
  };
  useEffect(() => {
    fetchLookerGroups();
  }, []);

  const emptyTab = { name: "", folderId: "", dashboardSortOrder: [] };
  // Add/remove tab inputs
  const addTab = () => {
    setTempAppConfig((prev) =>
      produce(prev, (draft) => {
        draft.tabs.push(emptyTab);
      })
    );
  };

  const removeTab = (tabIndex) => {
    setTempAppConfig((prev) => ({
      ...prev,
      tabs: prev.tabs.filter((tab, index) => index !== tabIndex),
    }));
  };

  // Update state when tab input values change
  const updateTab = (property, newValue, tabIndex) => {
    setTempAppConfig((prev) => {
      const newTabs = [...prev.tabs];
      newTabs[tabIndex] = {
        ...newTabs[tabIndex],
        [property]: newValue,
      };
      return {
        ...prev,
        tabs: newTabs,
      };
    });
  };

  const addNestedTab = (tabIndex) => {
    setTempAppConfig((prev) =>
      produce(prev, (draft) => {
        if (!draft.tabs[tabIndex].children) {
          draft.tabs[tabIndex].children = [];
        }
        draft.tabs[tabIndex].children.push(emptyTab);
      })
    );
  };

  const removeNestedTab = (tabIndex, nestedTabIndex) => {
    setTempAppConfig((prev) =>
      produce(prev, (draft) => {
        draft.tabs[tabIndex].children = draft.tabs[tabIndex].children.filter(
          (nestedTab, index) => index !== nestedTabIndex
        );
      })
    );
  };

  // Update state when nested tab input values change
  const updateNestedTab = (property, newValue, tabIndex, nestedTabIndex) => {
    setTempAppConfig((prev) =>
      produce(prev, (draft) => {
        draft.tabs[tabIndex].children[nestedTabIndex][property] = newValue;
      })
    );
  };

  // update state from app and dashboard form fields
  const updateConfig = (configValueName, newValue) => {
    setTempAppConfig((prev) =>
      produce(prev, (draft) => {
        draft[configValueName] = newValue;
      })
    );
  };

  // handle logo image upload
  const handleFileUpload = useCallback((acceptedFiles) => {
    const file = acceptedFiles[0];
    const reader = new FileReader();

    reader.onabort = () => console.log("File reading was aborted");
    reader.onerror = () => console.error("File reading failed");
    reader.onload = () => {
      const dataURL = reader.result;
      updateConfig("logoDataURL", dataURL);
    };

    reader.readAsDataURL(file);
  }, []);

  return (
    <>
      <DialogContent>
        {/*<DialogContentSection headingText="App" top>
          <Stack alignItems="flex-start" spacing={3}>
            <TextField
              value={tempAppConfig.logoHeight ?? defaultLogoHeight}
              onChange={(e) => updateConfig("logoHeight", e.target.value)}
              variant="outlined"
              label={`Logo Height (px)`}
              size="small"
              sx={{ pb: 1 }}
            />
            <Stack direction="row" spacing={2} alignItems="center">
              <Dropzone onDrop={handleFileUpload}>
                {({ getRootProps, getInputProps }) => (
                  <Button
                    {...getRootProps()}
                    component="span"
                    variant="contained"
                    size="small"
                    startIcon={<FileUpload />}
                  >
                    Update Logo
                    <input {...getInputProps()} />
                  </Button>
                )}
              </Dropzone>
              <img
                src={
                  tempAppConfig.logoDataURL
                    ? tempAppConfig.logoDataURL
                    : defaultLogo
                }
                alt="company logo"
                height={
                  tempAppConfig.logoHeight
                    ? `${tempAppConfig.logoHeight}px`
                    : `${defaultLogoHeight}px`
                }
              />
            </Stack>
          </Stack>
        </DialogContentSection>*/}
        <DialogContentSection headingText="Dashboard" top>
          <FormControlLabel
            control={
              <Switch
                checked={tempAppConfig.showDashboardFilters}
                onChange={(event) =>
                  updateConfig("showDashboardFilters", event.target.checked)
                }
              />
            }
            label="Show Dashboard Filters"
          />
        </DialogContentSection>
        <DialogContentSection headingText="Tab Navigation">
          <Stack alignItems="flex-start">
            {tempAppConfig.tabs?.map((tab, tabIndex) => (
              <TabConfigRow
                addNestedTab={addNestedTab}
                tabIndex={tabIndex}
                tab={tab}
                updateNestedTab={updateNestedTab}
                updateTab={updateTab}
                key={tabIndex}
                removeNestedTab={removeNestedTab}
                removeTab={removeTab}
                showTabIcons={tempAppConfig.showTabIcons}
                setSelectedTab={setSelectedTab}
                allGroups={allGroups}
              />
            ))}
            <Button
              startIcon={<CreateNewFolder />}
              variant="contained"
              sx={{ my: 2 }}
              onClick={addTab}
            >
              Add Tab
            </Button>
          </Stack>
        </DialogContentSection>
      </DialogContent>
      <DialogActions>
        <Button onClick={closeModal}>Cancel</Button>
        <LoadingButton
          loading={isSavingConfig}
          variant="contained"
          onClick={() => saveConfigChanges(tempAppConfig)}
        >
          Save Changes
        </LoadingButton>
      </DialogActions>
    </>
  );
};
